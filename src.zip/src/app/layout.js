import "./globals.css";
import Navbar from "@/components/Navbar";
import Providers from "./providers";

export const metadata = {
  title: "E-Commerce",
  description: "Premium Store",
};

export default function RootLayout({ children }) {
  return (
    <html lang="tr">
      <body>
        <Providers>
          <div>{children}</div>
        </Providers>
      </body>
    </html>
  );
}
