"use client";

import { useCartStore } from "@/store/cartStore";
import Link from "next/link";
import { ShoppingCart, Trash2, Minus, Plus, CreditCard } from "lucide-react";

export default function CartPage() {
  const { cart, removeFromCart, increaseQty, decreaseQty } = useCartStore();

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-12 flex flex-col items-center text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-5 py-2 backdrop-blur-xl">
          <ShoppingCart size={18} className="text-blue-200" />
          <span className="text-sm font-semibold text-white/70">Sepetim</span>
        </div>

        <h1 className="bg-gradient-to-r from-white via-blue-200 to-purple-300 bg-clip-text text-4xl font-black text-transparent md:text-6xl">
          Sepetim
        </h1>

        <p className="mt-5 max-w-2xl text-base leading-8 text-white/70 md:text-lg">
          Sepetindeki ürünleri kontrol et, adetleri güncelle ve ödeme adımına
          geç.
        </p>
      </div>

      {cart.length === 0 ? (
        <div className="rounded-[36px] border border-white/10 bg-white/10 p-12 text-center shadow-2xl backdrop-blur-2xl">
          <h2 className="text-3xl font-black text-white">Sepet boş</h2>

          <p className="mt-4 text-white/65">
            Alışverişe başlamak için ürünleri inceleyebilirsin.
          </p>

          <Link
            href="/products"
            className="mt-8 inline-flex items-center justify-center rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500 px-8 py-4 font-black text-white shadow-xl transition hover:scale-[1.02] hover:opacity-95"
          >
            Ürünlere Git
          </Link>
        </div>
      ) : (
        <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
          <div className="space-y-6">
            {cart.map((item) => (
              <div
                key={item._id}
                className="rounded-[32px] border border-white/10 bg-white/10 p-6 shadow-2xl backdrop-blur-2xl"
              >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                  <div>
                    <h2 className="text-2xl font-black text-white">
                      {item.title}
                    </h2>

                    <p className="mt-2 text-xl font-bold text-blue-200">
                      ₺{Number(item.price).toLocaleString("tr-TR")}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-slate-950/40 px-4 py-3">
                      <button
                        onClick={() => decreaseQty(item._id)}
                        className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 text-white transition hover:bg-white/20"
                      >
                        <Minus size={18} />
                      </button>

                      <span className="min-w-8 text-center text-lg font-black text-white">
                        {item.quantity}
                      </span>

                      <button
                        onClick={() => increaseQty(item._id)}
                        className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 text-white transition hover:bg-white/20"
                      >
                        <Plus size={18} />
                      </button>
                    </div>

                    <button
                      onClick={() => removeFromCart(item._id)}
                      className="flex h-12 w-12 items-center justify-center rounded-2xl bg-red-500 text-white transition hover:bg-red-600"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <aside className="h-fit rounded-[36px] border border-white/10 bg-white/10 p-8 shadow-2xl backdrop-blur-2xl">
            <h2 className="text-2xl font-black text-white">Sipariş Özeti</h2>

            <div className="mt-6 space-y-4 border-b border-white/10 pb-6">
              <div className="flex justify-between text-white/70">
                <span>Ürün Sayısı</span>
                <span>{cart.length}</span>
              </div>

              <div className="flex justify-between text-white/70">
                <span>Ara Toplam</span>
                <span>₺{Number(total).toLocaleString("tr-TR")}</span>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between">
              <span className="text-lg font-bold text-black">Toplam</span>
              <span className="text-3xl font-black text-black">
                ₺{Number(total).toLocaleString("tr-TR")}
              </span>
            </div>

            <Link
              href="/checkout"
              className="mt-8 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-rpx-6 py-4 font-black text-black shadow-xl transition hover:scale-[1.02] hover:opacity-95"
            >
              <CreditCard size={20} />
              Checkout
            </Link>
          </aside>
        </div>
      )}
    </main>
  );
}
