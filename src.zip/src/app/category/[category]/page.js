import { connectDB } from "@/lib/mongodb";
import Product from "@/models/Product";
import ProductGrid from "@/components/ProductGrid";
import { PackageSearch } from "lucide-react";

async function getProducts(category) {
  await connectDB();

  const decodedCategory = decodeURIComponent(category).trim();

  const products = await Product.find({
    category: decodedCategory,
  }).sort({
    createdAt: -1,
  });

  return JSON.parse(JSON.stringify(products));
}

export default async function CategoryPage({ params }) {
  const { category } = await params;

  const decodedCategory = decodeURIComponent(category).trim();

  const products = await getProducts(category);

  return (
    <main className="mx-auto w-full max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-14 flex flex-col items-center text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full  px-5 py-2 backdrop-blur-xl">
          <PackageSearch size={18} className="text-black" />

          <span className="text-sm font-semibold text-black">
            Kategori Sayfası
          </span>
        </div>

        <h1 className=" bg-clip-text text-4xl font-black text-transparent md:text-6xl">
          {decodedCategory}
        </h1>

        <p className="mt-6 max-w-2xl text-base leading-8 text-black md:text-lg">
          {decodedCategory} kategorisindeki ürünleri keşfedin ve size en uygun
          seçenekleri inceleyin.
        </p>
      </div>

      {products.length === 0 ? (
        <div className="rounded-[36px] border p-12 text-center shadow-2xl backdrop-blur-2xl">
          <h2 className="text-3xl font-black text-black">Ürün Bulunamadı</h2>

          <p className="mt-5 text-lg leading-8 text-black">
            Bu kategoride henüz ürün bulunmuyor.
          </p>
        </div>
      ) : (
        <div className="mt-6">
          <ProductGrid products={products} />
        </div>
      )}
    </main>
  );
}
