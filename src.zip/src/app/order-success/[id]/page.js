import { connectDB } from "@/lib/mongodb";
import Order from "@/models/Order";
import Link from "next/link";
import { CheckCircle2, PackageSearch, Mail, ShieldCheck } from "lucide-react";

async function getOrder(id) {
  await connectDB();

  const order = await Order.findById(id);

  return JSON.parse(JSON.stringify(order));
}

export default async function OrderSuccessPage({ params }) {
  const { id } = await params;

  const order = await getOrder(id);

  if (!order) {
    return (
      <main className="flex min-h-[70vh] items-center justify-center px-4 py-10">
        <div className="rounded-[36px] border p-12 text-center shadow-2xl backdrop-blur-2xl">
          <h1 className="text-4xl font-black text-white">Sipariş Bulunamadı</h1>

          <p className="mt-5 text-lg text-black">
            Böyle bir sipariş kaydı bulunamadı.
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="flex min-h-[80vh] items-center justify-center px-4 py-10">
      <div className="w-full max-w-3xl rounded-[40px] border p-8 shadow-2xl backdrop-blur-2xl sm:p-10 lg:p-12">
        <div className="flex flex-col items-center text-center">
          <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-full text-black">
            <CheckCircle2 size={52} className="text-green-300" />
          </div>

          <div className="mb-5 inline-flex items-center gap-2 rounded-full border  px-5 py-2 backdrop-blur-xl">
            <ShieldCheck size={18} className="text-black" />

            <span className="text-sm font-semibold text-black">
              Sipariş Başarılı
            </span>
          </div>

          <h1 className="bg-gradient-to-r text-black bg-clip-text text-4xl font-black  md:text-6xl">
            Siparişiniz Alındı
          </h1>

          <p className="mt-6 max-w-2xl text-base leading-8 text-black md:text-lg">
            Siparişiniz başarıyla oluşturuldu. Sipariş durumunuzu takip etmek
            için aşağıdaki sipariş kodunu saklayın.
          </p>
        </div>

        <div className="mt-10 rounded-[32px] border p-8 text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-black">
            Sipariş Kodu
          </p>

          <p className="mt-5 break-all text-3xl font-black tracking-[0.25em] text-black sm:text-4xl">
            {order.orderCode}
          </p>
        </div>

        <div className="mt-8 flex items-center gap-4 rounded-3xl border  p-5">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl ">
            <Mail size={26} className="text-black" />
          </div>

          <div>
            <p className="text-sm font-semibold text-black">Sipariş Emaili</p>

            <p className="mt-1 text-lg font-bold text-black">
              {order.customer?.email}
            </p>
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-4 sm:flex-row">
          <Link
            href="/track-order"
            className="flex flex-1 items-center justify-center gap-3 rounded-2xl  px-6 py-5 text-lg font-black text-white shadow-xl transition hover:scale-[1.01] hover:opacity-95"
          >
            <PackageSearch size={22} />
            Sipariş Takip Et
          </Link>

          <Link
            href="/"
            className="flex flex-1 items-center justify-center rounded-2xl border px-6 py-5 text-lg font-bold text-black transition hover:bg-white/20"
          >
            Ana Sayfaya Dön
          </Link>
        </div>
      </div>
    </main>
  );
}
