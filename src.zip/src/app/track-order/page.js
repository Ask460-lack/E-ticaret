"use client";

import { useState } from "react";
import axios from "axios";
import {
  Search,
  Mail,
  ShieldCheck,
  PackageSearch,
  PackageCheck,
  Truck,
  CheckCircle2,
} from "lucide-react";
import Navbar from "@/components/Navbar";

export default function TrackOrderPage() {
  const [form, setForm] = useState({
    email: "",
    orderCode: "",
  });

  const [order, setOrder] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post("/api/orders/track", form);

      setOrder(res.data);
    } catch (error) {
      setOrder(null);

      alert(error.response?.data?.error || "Sipariş bulunamadı");
    }
  };

  return (
    <main className=" w-full flex h-screen flex-col items-center ">
      <Navbar />
      <div className="flex flex-col items-center text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border px-5 py-2 backdrop-blur-xl">
          <PackageSearch size={18} className="text-black" />
          <span className="text-sm font-semibold text-black">
            Sipariş Takibi
          </span>
        </div>

        <h1 className="p-5  -4xl font-black text-black md:text-6xl">
          Sipariş Takip
        </h1>

        <p className="mt-6 max-w-2xl text-base leading-8 text-black md:text-lg">
          Sipariş kodunuz ve email adresiniz ile sipariş durumunuzu kolayca
          sorgulayabilirsiniz.
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="w-full lg:w-1/2 h-1/5 shadow-2xl flex flex-col backdrop-blur-2xl sm:p-8 p-5"
      >
        <label className="text-sm font-semibold text-black ">
          Email Adresi
        </label>

        <div className="relative ">
          <Mail
            size={20}
            className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400"
          />

          <input
            type="email"
            placeholder="ornek@email.com"
            className="w-full rounded-2xl border border-white/10 bg-slate-950/60 py-4 pl-4 pr-14 text-base font-medium text-white placeholder:text-slate-400 outline-none transition focus:border-blue-400 focus:bg-slate-950"
            value={form.email}
            onChange={(e) =>
              setForm({
                ...form,
                email: e.target.value,
              })
            }
          />
        </div>
        <div className="h-3"></div>
        <div className="space-y-2">
          <label className="text-sm font-semibold text-black">
            Sipariş Kodu
          </label>

          <div className="relative">
            <ShieldCheck
              size={20}
              className="absolute right-5 top-1/2 -translate-y-1/2 text-black"
            />

            <input
              placeholder="ORD-ABC123"
              className="w-full rounded-2xl border py-4 pl-4 pr-14 text-base font-medium uppercase text-black placeholder:text-slate-400 outline-none transition focus:border-blue-400 focus:bg-slate-950"
              value={form.orderCode}
              onChange={(e) =>
                setForm({
                  ...form,
                  orderCode: e.target.value,
                })
              }
            />
          </div>
        </div>
        <div className="h-5"></div>
        <button className="flex w-full items-center justify-center gap-3 rounded-2xl  px-6 py-4 text-lg font-black text-black shadow-xl transition hover:scale-[1.01] hover:opacity-95">
          <Search size={22} />
          Siparişi Sorgula
        </button>
      </form>

      {order && (
        <div className="mt-10 rounded-[36px] border border-white/10 bg-white/10 p-8 shadow-2xl backdrop-blur-2xl">
          <div className="mb-8 flex flex-col gap-5 border-b border-white/10 pb-8 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-widest text-white/40">
                Sipariş Durumu
              </p>

              <div className="mt-3 flex items-center gap-3">
                {order.status === "hazırlanıyor" && (
                  <PackageCheck className="text-yellow-300" />
                )}

                {order.status === "kargoda" && (
                  <Truck className="text-blue-300" />
                )}

                {order.status === "teslim edildi" && (
                  <CheckCircle2 className="text-green-300" />
                )}

                <span className="text-2xl font-black capitalize text-white">
                  {order.status}
                </span>
              </div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-slate-950/40 px-5 py-4">
              <p className="text-sm text-white/40">Sipariş Kodu</p>

              <p className="mt-2 text-xl font-black tracking-wider text-blue-200">
                {order.orderCode}
              </p>
            </div>
          </div>

          <div className="mb-8 rounded-3xl border border-white/10 bg-slate-950/40 p-5">
            <p className="text-sm font-semibold text-white/40">
              Sipariş Emaili
            </p>

            <p className="mt-2 text-lg font-bold text-white">
              {order.customer?.email}
            </p>
          </div>

          <div className="space-y-5">
            {order.items.map((item, index) => (
              <div
                key={index}
                className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-slate-950/40 p-5 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <h3 className="font-bold text-white">{item.title}</h3>

                  <p className="mt-2 text-sm text-white/60">
                    Adet: {item.quantity}
                  </p>
                </div>

                <p className="text-lg font-black text-blue-200">
                  ₺{(item.price * item.quantity).toLocaleString("tr-TR")}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-8 flex items-center justify-between border-t border-white/10 pt-6">
            <span className="text-lg font-bold text-white">Toplam</span>

            <span className="text-3xl font-black text-blue-200">
              ₺{Number(order.total).toLocaleString("tr-TR")}
            </span>
          </div>
        </div>
      )}
    </main>
  );
}
