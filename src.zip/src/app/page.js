import Navbar from "@/components/Navbar";
import ProductGrid from "@/components/ProductGrid";
import { connectDB } from "@/lib/mongodb";
import Product from "@/models/Product";

async function getProducts() {
  await connectDB();

  const products = await Product.find().sort({
    createdAt: -1,
  });

  return JSON.parse(JSON.stringify(products));
}

export default async function HomePage() {
  const products = await getProducts();

  return (
    <main className="flex min-h-screen w-full flex-col items-center px-4 pt-10 pb-6 sm:px-6 lg:px-8">
      <section className="w-full flex flex-col gap-y-10">
        <div className="mb-14 flex flex-col items-center justify-center text-center gap-y-1.5 ">
          <div className="mb-6 inline-flex rounded-full border border-white/10 bg-white/5 px-4 py-2 backdrop-blur-lg">
            <span className="text-sm font-medium text-white/70">
              Premium Collection
            </span>
          </div>

          <h1 className="bg-gradient-to-r from-white via-blue-200 to-purple-300 bg-clip-text text-4xl font-black tracking-tight text-transparent md:text-6xl">
            Öne Çıkan Ürünler
          </h1>

          <p className="mt-5 max-w-2xl text-base text-white/70 md:text-lg">
            En yeni ve popüler ürünlerimizi modern tasarım ve premium deneyim
            ile keşfedin.
          </p>
        </div>

        <div className=" items-center ">
          <ProductGrid products={products} />
        </div>
      </section>
    </main>
  );
}
