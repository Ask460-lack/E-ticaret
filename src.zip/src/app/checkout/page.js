"use client";

import { useState } from "react";
import { useCartStore } from "@/store/cartStore";
import { useSession } from "next-auth/react";
import axios from "axios";
import { useRouter } from "next/navigation";
import { CreditCard, ShieldCheck, ShoppingBag, Lock } from "lucide-react";

export default function CheckoutPage() {
  const router = useRouter();
  const { data: session } = useSession();

  const { cart, clearCart } = useCartStore();

  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    name: "",
    email: "",
    address: "",
    phone: "",
  });

  const [card, setCard] = useState({
    cardHolderName: "",
    cardNumber: "",
    expireMonth: "",
    expireYear: "",
    cvc: "",
  });

  const total = cart.reduce((sum, item) => {
    return sum + item.price * item.quantity;
  }, 0);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (cart.length === 0) {
      alert("Sepetiniz boş");
      return;
    }

    const emailToUse = session?.user?.email || form.email;

    if (!form.name || !emailToUse || !form.address || !form.phone) {
      alert("Lütfen müşteri bilgilerini doldurun");
      return;
    }

    if (
      !card.cardHolderName ||
      !card.cardNumber ||
      !card.expireMonth ||
      !card.expireYear ||
      !card.cvc
    ) {
      alert("Lütfen kart bilgilerini doldurun");
      return;
    }

    try {
      setLoading(true);

      const paymentData = {
        items: cart.map((item) => ({
          productId: item._id || item.productId,
          quantity: item.quantity,
        })),

        customer: {
          userId: session?.user?.id || "",
          name: form.name,
          email: emailToUse,
          address: form.address,
          phone: form.phone,
        },

        card,
      };

      const res = await axios.post("/api/payment", paymentData);

      clearCart();

      alert("Ödeme başarılı");

      router.push(`/order-success/${res.data.order._id}`);
    } catch (error) {
      alert(error.response?.data?.error || "Ödeme işlemi başarısız");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="mx-auto w-full max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-14 flex flex-col items-center text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-5 py-2 backdrop-blur-xl">
          <ShieldCheck size={18} className="text-black" />

          <span className="text-sm font-semibold text-black">
            Güvenli Ödeme
          </span>
        </div>

        <h1 className=" bg-clip-text text-4xl font-black text-transparent md:text-6xl">
          Checkout
        </h1>

        <p className="mt-6 max-w-2xl text-base leading-8 text-black md:text-lg">
          Sipariş bilgilerinizi kontrol edin ve güvenli ödeme işlemini
          tamamlayın.
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
        <form
          onSubmit={handleSubmit}
          className="rounded-[36px] border border-white/10 bg-white/10 p-6 shadow-2xl backdrop-blur-2xl sm:p-8 lg:p-10"
        >
          <div className="space-y-10">
            <div>
              <div className="mb-6 flex items-center gap-3">
                <ShoppingBag className="text-blue-200" />

                <h2 className="text-2xl font-black text-white">
                  Teslimat Bilgileri
                </h2>
              </div>

              <div className="grid gap-5 md:grid-cols-2">
                <input
                  placeholder="Ad Soyad"
                  value={form.name}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      name: e.target.value,
                    })
                  }
                  className="rounded-2xl border border-white/10 bg-white p-4 font-medium text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-400"
                />

                <input
                  placeholder="Email"
                  value={session?.user?.email || form.email}
                  disabled={!!session?.user?.email}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      email: e.target.value,
                    })
                  }
                  className="rounded-2xl border border-white/10 bg-white p-4 font-medium text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-400 disabled:bg-slate-200"
                />

                <input
                  placeholder="Telefon"
                  value={form.phone}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      phone: e.target.value,
                    })
                  }
                  className="rounded-2xl border border-white/10 bg-white p-4 font-medium text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-400"
                />

                <input
                  placeholder="Adres"
                  value={form.address}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      address: e.target.value,
                    })
                  }
                  className="rounded-2xl border border-white/10 bg-white p-4 font-medium text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400"
                />
              </div>
            </div>

            <div>
              <div className="mb-6 flex items-center gap-3">
                <CreditCard className="text-black" />

                <h2 className="text-2xl font-black text-black">
                  Kart Bilgileri
                </h2>
              </div>

              <div className="grid gap-5 md:grid-cols-2">
                <input
                  placeholder="Kart Üzerindeki İsim"
                  value={card.cardHolderName}
                  onChange={(e) =>
                    setCard({
                      ...card,
                      cardHolderName: e.target.value,
                    })
                  }
                  className="rounded-2xl border border-white/10 bg-white p-4 font-medium text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400 md:col-span-2"
                />

                <input
                  placeholder="Kart Numarası"
                  value={card.cardNumber}
                  onChange={(e) =>
                    setCard({
                      ...card,
                      cardNumber: e.target.value,
                    })
                  }
                  className="rounded-2xl border border-white/10 bg-white p-4 font-medium text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400 md:col-span-2"
                />

                <input
                  placeholder="Ay Örn: 12"
                  value={card.expireMonth}
                  onChange={(e) =>
                    setCard({
                      ...card,
                      expireMonth: e.target.value,
                    })
                  }
                  className="rounded-2xl border border-white/10 bg-white p-4 font-medium text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400"
                />

                <input
                  placeholder="Yıl Örn: 2030"
                  value={card.expireYear}
                  onChange={(e) =>
                    setCard({
                      ...card,
                      expireYear: e.target.value,
                    })
                  }
                  className="rounded-2xl border border-white/10 bg-white p-4 font-medium text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400"
                />

                <input
                  placeholder="CVC"
                  value={card.cvc}
                  onChange={(e) =>
                    setCard({
                      ...card,
                      cvc: e.target.value,
                    })
                  }
                  className="rounded-2xl border border-white/10 text-black p-4 font-medium text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-400"
                />
              </div>
            </div>

            <button
              disabled={loading}
              className="flex w-full items-center justify-center gap-3 rounded-2xl px-6 py-5 text-lg font-black text-black shadow-xl transition hover:scale-[1.01] hover:opacity-95 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <Lock size={22} />

              {loading
                ? "Ödeme İşleniyor..."
                : `₺${Number(total).toLocaleString("tr-TR")} Öde`}
            </button>
          </div>
        </form>

        <aside className="h-fit rounded-[36px] border  p-8 shadow-2xl backdrop-blur-2xl">
          <h2 className="text-2xl font-black text-black">Sipariş Özeti</h2>

          <div className="mt-8 space-y-5">
            {cart.map((item) => (
              <div
                key={item._id}
                className="flex items-center justify-between gap-4 rounded-2xl border p-4"
              >
                <div>
                  <p className="font-bold text-black">{item.title}</p>

                  <p className="mt-1 text-sm text-black">
                    Adet: {item.quantity}
                  </p>
                </div>

                <p className="shrink-0 font-black text-black">
                  ₺{(item.price * item.quantity).toLocaleString("tr-TR")}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-8 flex items-center justify-between t-6">
            <span className="text-lg font-bold text-black">Toplam</span>

            <span className="text-3xl font-black text-black">
              ₺{Number(total).toLocaleString("tr-TR")}
            </span>
          </div>

          <div className="mt-8 rounded-3xl border p-5 text-sm leading-7 text-black">
            Test aşamasında iyzico sandbox kullanılır. Gerçek para çekilmez.
          </div>
        </aside>
      </div>
    </main>
  );
}
