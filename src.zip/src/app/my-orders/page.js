"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import { ShoppingBag, PackageCheck, Truck, CheckCircle2 } from "lucide-react";

export default function MyOrdersPage() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    const res = await axios.get("/api/my-orders");
    setOrders(res.data);
  };

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-14 flex flex-col items-center text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-5 py-2 backdrop-blur-xl">
          <ShoppingBag size={18} className="text-blue-200" />

          <span className="text-sm font-semibold text-white/70">
            Sipariş Takibi
          </span>
        </div>

        <h1 className="bg-gradient-to-r from-white via-blue-200 to-purple-300 bg-clip-text text-4xl font-black text-transparent md:text-6xl">
          Siparişlerim
        </h1>

        <p className="mt-6 max-w-2xl text-base leading-8 text-white/70 md:text-lg">
          Verdiğiniz siparişleri, ürün detaylarını ve güncel durumlarını buradan
          takip edebilirsiniz.
        </p>
      </div>

      {orders.length === 0 ? (
        <div className="rounded-[36px] border p-12 text-center shadow-2xl backdrop-blur-2xl">
          <h2 className="text-3xl font-black text-black">
            Henüz siparişiniz yok
          </h2>

          <p className="mt-5 text-lg leading-8 text-black">
            Sipariş verdiğinizde durumunu buradan takip edebilirsiniz.
          </p>
        </div>
      ) : (
        <div className="space-y-14">
          {orders.map((order) => (
            <div
              key={order._id}
              className="rounded-[36px] border text-black p-8 shadow-2xl backdrop-blur-2xl"
            >
              <div className="mb-8 flex flex-col gap-5 border-b  pb-8 md:flex-row md:items-center md:justify-between">
                <div>
                  <p className="text-sm font-semibold uppercase tracking-widest text-black">
                    Sipariş Durumu
                  </p>

                  <div className="mt-3 flex items-center gap-3">
                    {order.status === "hazırlanıyor" && (
                      <PackageCheck className="text-yellow-300" />
                    )}

                    {order.status === "kargoda" && (
                      <Truck className="text-black" />
                    )}

                    {order.status === "teslim edildi" && (
                      <CheckCircle2 className="text-black" />
                    )}

                    <span className="text-xl font-black capitalize text-black">
                      {order.status}
                    </span>
                  </div>
                </div>

                <div className="rounded-2xl border border-white/10 bg-slate-950/40 px-5 py-4">
                  <p className="text-sm text-black">Toplam Tutar</p>

                  <p className="mt-1 text-3xl font-black text-black">
                    ₺{Number(order.total).toLocaleString("tr-TR")}
                  </p>
                </div>
              </div>

              <div className="space-y-5">
                {order.items.map((item, index) => (
                  <div
                    key={index}
                    className="flex flex-col gap-3 rounded-2xl border p-5 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div>
                      <h3 className="font-bold text-black">{item.title}</h3>

                      <p className="mt-2 text-sm text-black/60">
                        Adet: {item.quantity}
                      </p>
                    </div>

                    <p className="text-lg font-black text-black">
                      ₺{(item.price * item.quantity).toLocaleString("tr-TR")}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
