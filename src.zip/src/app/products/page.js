import { connectDB } from "@/lib/mongodb";
import Product from "@/models/Product";
import ProductFilterClient from "@/components/ProductFilterClient";

async function getProducts() {
  await connectDB();

  const products = await Product.find().sort({
    createdAt: -1,
  });

  return JSON.parse(JSON.stringify(products));
}

export default async function ProductsPage() {
  const products = await getProducts();

  return (
    <div className="w-full flex justify-center">
      <ProductFilterClient products={products} />
    </div>
  );
}
