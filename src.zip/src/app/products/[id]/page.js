import { connectDB } from "@/lib/mongodb";
import Product from "@/models/Product";
import ProductDetailClient from "@/components/ProductDetailClient";
import { PackageX } from "lucide-react";
import Link from "next/link";

async function getProduct(id) {
  await connectDB();

  const product = await Product.findById(id);

  return JSON.parse(JSON.stringify(product));
}

export default async function ProductDetailPage({ params }) {
  const { id } = await params;

  const product = await getProduct(id);

  if (!product) {
    return (
      <main className="flex min-h-[70vh] items-center justify-center px-4 py-10">
        <div className="w-full max-w-2xl rounded-[40px] border border-white/10 bg-white/10 p-10 text-center shadow-2xl backdrop-blur-2xl">
          <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-red-500/20">
            <PackageX size={52} className="text-red-300" />
          </div>

          <h1 className="bg-gradient-to-r from-white via-red-200 to-pink-300 bg-clip-text text-4xl font-black text-transparent">
            Ürün Bulunamadı
          </h1>

          <p className="mt-6 text-lg leading-8 text-white/65">
            Aradığınız ürün mevcut değil veya kaldırılmış olabilir.
          </p>

          <Link
            href="/products"
            className="mt-8 inline-flex items-center justify-center rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500 px-8 py-4 font-black text-white shadow-xl transition hover:scale-[1.02] hover:opacity-95"
          >
            Ürünlere Dön
          </Link>
        </div>
      </main>
    );
  }

  return <ProductDetailClient product={product} />;
}
