"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import axios from "axios";
import { PackageCheck, Truck, CheckCircle2, ShoppingBag } from "lucide-react";

export default function AdminOrdersPage() {
  const { data: session, status } = useSession();
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    const res = await axios.get("/api/orders");
    setOrders(res.data);
  };

  useEffect(() => {
    if (status === "authenticated" && session?.user?.role === "admin") {
      fetchOrders();
    }
  }, [status, session]);

  const updateStatus = async (id, newStatus) => {
    await axios.patch(`/api/orders/${id}`, {
      status: newStatus,
    });

    fetchOrders();
  };

  if (status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center text-2xl font-bold text-black">
        Yükleniyor...
      </div>
    );
  }

  if (status === "unauthenticated") {
    return (
      <div className="flex min-h-screen items-center justify-center text-3xl font-black text-black">
        Lütfen giriş yapın.
      </div>
    );
  }

  if (session?.user?.role !== "admin") {
    return (
      <div className="flex min-h-screen items-center justify-center text-3xl font-black text-black">
        Yetkisiz erişim
      </div>
    );
  }

  return (
    <main className=" w-full  px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-14 flex flex-col items-center text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border px-5 py-2 backdrop-blur-xl">
          <ShoppingBag size={18} className="text-black" />

          <span className="text-sm font-semibold text-black">
            Sipariş Yönetimi
          </span>
        </div>

        <h1 className="bg-gradient-to-r bg-clip-text text-4xl font-black text-black md:text-6xl">
          Siparişler
        </h1>

        <p className="mt-6 max-w-2xl text-base leading-8 text-black md:text-lg">
          Gelen siparişleri yönetin, durumlarını güncelleyin ve müşteri
          bilgilerini görüntüleyin.
        </p>
      </div>

      {orders.length === 0 ? (
        <div className="rounded-[36px] borderp-12 text-center shadow-2xl backdrop-blur-2xl">
          <h2 className="text-3xl font-black text-black">Henüz sipariş yok</h2>

          <p className="mt-5 text-lg text-black">
            Yeni siparişler burada görüntülenecek.
          </p>
        </div>
      ) : (
        <div className="space-y-16">
          {orders.map((order) => (
            <div
              key={order._id}
              className="rounded-[36px] border p-10 shadow-2xl backdrop-blur-2xl"
            >
              <div className="flex flex-col gap-12 lg:flex-row lg:items-start lg:justify-between">
                <div className="flex-1 space-y-8">
                  <div>
                    <h2 className="text-2xl font-black text-black">
                      {order.customer?.name}
                    </h2>

                    <div className="mt-5 space-y-3 text-black/70">
                      <p>{order.customer?.email}</p>
                      <p>{order.customer?.phone}</p>
                      <p>{order.customer?.address}</p>
                    </div>
                  </div>

                  <div className="rounded-3xl border p-7">
                    <h3 className="mb-6 text-lg font-black text-black">
                      Sipariş Ürünleri
                    </h3>

                    <div className="space-y-5">
                      {order.items?.map((item, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between gap-6 rounded-2xl px-5 py-4"
                        >
                          <span className="font-medium text-black">
                            {item.title} x {item.quantity}
                          </span>

                          <span className="shrink-0 font-bold text-black">
                            ₺
                            {(item.price * item.quantity).toLocaleString(
                              "tr-TR",
                            )}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="w-full rounded-3xl border p-8 lg:max-w-sm">
                  <div className="mb-8">
                    <p className="text-sm font-semibold uppercase tracking-widest text-black">
                      Sipariş Toplamı
                    </p>

                    <h3 className="mt-4 text-4xl font-black text-black">
                      ₺{Number(order.total).toLocaleString("tr-TR")}
                    </h3>
                  </div>

                  <div className="mb-6 flex items-center gap-4">
                    {order.status === "hazırlanıyor" && (
                      <PackageCheck className="text-yellow-300" />
                    )}

                    {order.status === "kargoda" && (
                      <Truck className="text-black" />
                    )}

                    {order.status === "teslim edildi" && (
                      <CheckCircle2 className="text-black" />
                    )}

                    <span className="font-bold capitalize text-black">
                      {order.status}
                    </span>
                  </div>

                  <select
                    value={order.status}
                    onChange={(e) => updateStatus(order._id, e.target.value)}
                    className="w-full rounded-2xl border px-4 py-4 font-semibold text-black outline-none transition focus:border-blue-400"
                  >
                    <option value="hazırlanıyor">Hazırlanıyor</option>
                    <option value="kargoda">Kargoda</option>
                    <option value="teslim edildi">Teslim Edildi</option>
                  </select>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
