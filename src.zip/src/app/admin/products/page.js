"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import { Package, Plus, UploadCloud, Pencil, Trash2, X } from "lucide-react";

export default function AdminProductsPage() {
  const [products, setProducts] = useState([]);
  const [editingId, setEditingId] = useState(null);

  const [form, setForm] = useState({
    title: "",
    description: "",
    price: "",
    images: "",
    category: "",
    stock: "",
  });

  const handleImageUpload = async (files) => {
    if (!files || files.length === 0) return;

    const data = new FormData();

    Array.from(files).forEach((file) => {
      data.append("files", file);
    });

    try {
      const res = await axios.post("/api/upload", data);
      const uploadedUrls = res.data.images.join("\n");

      setForm((prev) => ({
        ...prev,
        images: prev.images ? `${prev.images}\n${uploadedUrls}` : uploadedUrls,
      }));

      alert("Görseller yüklendi");
    } catch {
      alert("Görsel yükleme başarısız");
    }
  };

  const fetchProducts = async () => {
    const res = await axios.get("/api/products");
    setProducts(res.data);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm({
      title: "",
      description: "",
      price: "",
      images: "",
      category: "",
      stock: "",
    });
  };

  const validateForm = () => {
    if (
      !form.title ||
      !form.description ||
      !form.price ||
      !form.images ||
      !form.category ||
      form.stock === ""
    ) {
      alert("Lütfen tüm ürün bilgilerini doldurun");
      return false;
    }

    if (Number(form.price) <= 0) {
      alert("Fiyat 0'dan büyük olmalı");
      return false;
    }

    if (Number(form.stock) < 0) {
      alert("Stok negatif olamaz");
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    const imageArray = form.images
      .split("\n")
      .map((img) => img.trim())
      .filter(Boolean);

    const productData = {
      title: form.title,
      description: form.description,
      price: Number(form.price),
      images: imageArray,
      category: form.category,
      stock: Number(form.stock),
    };

    if (editingId) {
      await axios.patch(`/api/products/${editingId}`, productData);
      alert("Ürün güncellendi");
    } else {
      await axios.post("/api/products", productData);
      alert("Ürün eklendi");
    }

    resetForm();
    fetchProducts();
  };

  const handleEdit = (product) => {
    setEditingId(product._id);

    setForm({
      title: product.title || "",
      description: product.description || "",
      price: product.price || "",
      images: product.images?.join("\n") || "",
      category: product.category || "",
      stock: product.stock || "",
    });

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const handleDelete = async (id) => {
    const confirmDelete = confirm("Bu ürünü silmek istediğine emin misin?");

    if (!confirmDelete) return;

    await axios.delete(`/api/products/${id}`);
    alert("Ürün silindi");
    fetchProducts();
  };

  return (
    <main className=" w-full  px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-14 flex flex-col items-center text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border  px-5 py-2 backdrop-blur-xl">
          <Package size={18} className="text-black" />

          <span className="text-sm font-semibold text-white/70">
            Ürün Yönetimi
          </span>
        </div>

        <h1 className="bg-gradient-to-r  bg-clip-text text-4xl font-black text-transparent md:text-6xl">
          Ürün Yönetimi
        </h1>

        <p className="mt-6 max-w-2xl text-base leading-8 text-black md:text-lg">
          Yeni ürün ekleyin, mevcut ürünleri düzenleyin ve stok bilgilerini
          yönetin.
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="mb-16 rounded-[36px] border  p-6 shadow-2xl backdrop-blur-2xl sm:p-8 lg:p-10"
      >
        <div className="mb-8 flex flex-col gap-3">
          <h2 className="text-3xl font-black text-black">
            {editingId ? "Ürün Güncelle" : "Yeni Ürün Ekle"}
          </h2>

          <p className="text-black/65">
            Ürün bilgilerini eksiksiz doldurun. Görselleri yükleyebilir veya URL
            olarak ekleyebilirsiniz.
          </p>
        </div>

        <div className="grid gap-5 md:grid-cols-2">
          <input
            name="title"
            value={form.title}
            placeholder="Ürün adı"
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="rounded-2xl border border-white/10 bg-white p-4 font-medium text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400 md:col-span-2"
          />

          <textarea
            name="description"
            value={form.description}
            placeholder="Açıklama"
            onChange={(e) =>
              setForm({
                ...form,
                description: e.target.value,
              })
            }
            className="min-h-32 rounded-2xl border bg-white p-4 font-mediumtext-black placeholder:text-slate-500 outline-none transition focus:border-blue-400 md:col-span-2"
          />

          <input
            name="price"
            value={form.price}
            placeholder="Fiyat"
            type="number"
            onChange={(e) => setForm({ ...form, price: e.target.value })}
            className="rounded-2xl border  bg-white p-4 font-medium text-black placeholder:text-slate-500 outline-none transition "
          />

          <input
            name="stock"
            value={form.stock}
            placeholder="Stok"
            type="number"
            onChange={(e) => setForm({ ...form, stock: e.target.value })}
            className="rounded-2xl border   p-4 font-medium text-black placeholder:text-slate-500 outline-none transition "
          />

          <input
            name="category"
            value={form.category}
            placeholder="Kategori"
            onChange={(e) => setForm({ ...form, category: e.target.value })}
            className="rounded-2xl border  p-4 font-medium text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400 md:col-span-2"
          />

          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              handleImageUpload(e.dataTransfer.files);
            }}
            className="rounded-[28px] border-2 border-dashed   p-8 text-center md:col-span-2"
          >
            <UploadCloud size={42} className="mx-auto mb-4 text-black" />

            <p className="text-lg font-black text-black">
              Görselleri buraya sürükleyip bırak
            </p>

            <p className="mt-2 text-sm text-black/60">veya dosya seç</p>

            <input
              type="file"
              multiple
              accept="image/*"
              onChange={(e) => handleImageUpload(e.target.files)}
              className="mt-5 w-full cursor-pointer rounded-2xl  p-3 font-medium text-black file:mr-4 file:rounded-xl file:border-0 file:bg-slate-950 file:px-4 file:py-2 file:font-bold file:text-white"
            />
          </div>

          <textarea
            name="images"
            value={form.images}
            placeholder="Görsel URL'leri - her satıra bir görsel URL"
            onChange={(e) => setForm({ ...form, images: e.target.value })}
            className="min-h-36 rounded-2xl border   p-4 font-medium text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400 md:col-span-2"
          />
        </div>

        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <button className="inline-flex items-center justify-center gap-2 rounded-2xl  px-8 py-4 font-black text-black shadow-xl transition hover:scale-[1.02] hover:opacity-95">
            <Plus size={20} />
            {editingId ? "Güncelle" : "Ürün Ekle"}
          </button>

          {editingId && (
            <button
              type="button"
              onClick={resetForm}
              className="inline-flex items-center justify-center gap-2 rounded-2xl border px-8 py-4 font-bold text-black transition hover:bg-white/20"
            >
              <X size={20} />
              İptal
            </button>
          )}
        </div>
      </form>

      <div className="mb-8">
        <h2 className="text-3xl font-black text-black">Mevcut Ürünler</h2>
        <p className="mt-3 text-black">
          Sistemde kayıtlı ürünleri buradan düzenleyebilir veya silebilirsiniz.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-3">
        {products.map((product) => (
          <div
            key={product._id}
            className="overflow-hidden rounded-[32px] border p-5 shadow-2xl backdrop-blur-2xl transition hover:-translate-y-1"
          >
            <img
              src={product.images?.[0]}
              alt={product.title}
              className="mb-5 h-56 w-full rounded-2xl  object-contain p-4"
            />

            <h2 className="text-2xl font-black text-black">{product.title}</h2>

            <p className="mt-3 line-clamp-3 leading-7 text-black/65">
              {product.description}
            </p>

            <div className="mt-5 space-y-2 rounded-2xl border   p-4">
              <p className="text-xl font-black text-black">
                ₺{Number(product.price).toLocaleString("tr-TR")}
              </p>

              <p className="text-sm font-medium text-black/70">
                Kategori:{" "}
                <span className="font-bold text-black">{product.category}</span>
              </p>

              <p className="text-sm font-medium text-black/70">
                Stok:{" "}
                <span className="font-bold text-black">{product.stock}</span>
              </p>

              <p className="text-sm font-medium text-black/70">
                Görsel Sayısı:{" "}
                <span className="font-bold text-black">
                  {product.images?.length || 0}
                </span>
              </p>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => handleEdit(product)}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl  px-4 py-3 font-bold text-black transition hover:bg-blue-600"
              >
                <Pencil size={18} />
                Düzenle
              </button>

              <button
                onClick={() => handleDelete(product._id)}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xlpx-4 py-3 font-bold text-black transition hover:bg-red-600"
              >
                <Trash2 size={18} />
                Sil
              </button>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
