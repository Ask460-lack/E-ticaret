import Link from "next/link";
import { Package, ShoppingBag, ArrowLeft, ShieldCheck } from "lucide-react";

export default function AdminPage() {
  return (
    <main className=" flex min-h-screen w-full flex-col px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-12 flex flex-col items-center text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border px-5 py-2 backdrop-blur-xl">
          <ShieldCheck size={18} className="text-black" />

          <span className="text-sm font-semibold text-black/70">
            Yönetim Paneli
          </span>
        </div>

        <h1 className="bg-gradient-to-r bg-clip-text text-4xl font-black text-transparent md:text-6xl">
          Admin Dashboard
        </h1>

        <p className="mt-5 max-w-2xl text-base leading-8 text-black md:text-lg">
          Ürünleri yönetin, siparişleri takip edin ve mağazanızı kolayca kontrol
          edin.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-3">
        <Link
          href="/admin/products"
          className="group rounded-[32px] border p-8 shadow-2xl backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 "
        >
          <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl">
            <Package size={30} className="text-black" />
          </div>

          <h2 className="text-2xl font-black text-black">Ürün Yönetimi</h2>

          <p className="mt-4 leading-7 text-black">
            Yeni ürün ekleyin, mevcut ürünleri güncelleyin ve stok durumlarını
            yönetin.
          </p>

          <div className="mt-6 font-bold text-black transition group-hover:translate-x-1">
            Yönetimi Aç →
          </div>
        </Link>

        <Link
          href="/admin/orders"
          className="group rounded-[32px] border p-8 shadow-2xl backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2  "
        >
          <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-black">
            <ShoppingBag size={30} className="text-black" />
          </div>

          <h2 className="text-2xl font-black text-black">Siparişler</h2>

          <p className="mt-4 leading-7 text-black">
            Gelen siparişleri görüntüleyin, sipariş durumlarını kontrol edin ve
            müşterileri yönetin.
          </p>

          <div className="mt-6 font-bold text-black transition group-hover:translate-x-1">
            Siparişleri Gör →
          </div>
        </Link>

        <Link
          href="/"
          className="group rounded-[32px] border p-8 shadow-2xl backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:border-white/20 hover:bg-white/15"
        >
          <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl ">
            <ArrowLeft size={30} className="text-black" />
          </div>

          <h2 className="text-2xl font-black text-black">Siteye Dön</h2>

          <p className="mt-4 leading-7 text-black">
            Ana mağazaya geri dönün ve kullanıcı deneyimini görüntüleyin.
          </p>

          <div className="mt-6 font-bold text-black transition group-hover:translate-x-1">
            Ana Sayfaya Git →
          </div>
        </Link>
      </div>
    </main>
  );
}
