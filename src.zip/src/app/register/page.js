"use client";

import { useState } from "react";
import axios from "axios";
import { useRouter } from "next/navigation";
import { User, Mail, Lock, ShieldCheck, UserPlus } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    await axios.post("/api/register", form);

    alert("Kayıt başarılı");

    router.push("/login");
  };

  return (
    <main className="flex min-h-[80vh] items-center justify-center px-4 py-10">
      <div className="w-full max-w-md rounded-[36px] border border-white/10 bg-white/10 p-8 shadow-2xl backdrop-blur-2xl sm:p-10">
        <div className="mb-10 flex flex-col items-center text-center">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-5 py-2 backdrop-blur-xl">
            <ShieldCheck size={18} className="text-blue-200" />

            <span className="text-sm font-semibold text-white/70">
              Güvenli Kayıt
            </span>
          </div>

          <h1 className="bg-gradient-to-r from-white via-blue-200 to-purple-300 bg-clip-text text-4xl font-black text-transparent">
            Kayıt Ol
          </h1>

          <p className="mt-5 text-base leading-7 text-white/65">
            Yeni hesap oluşturun ve premium alışveriş deneyimine katılın.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-white/70">
              Ad Soyad
            </label>

            <div className="relative">
              <User
                size={20}
                className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400"
              />

              <input
                type="text"
                placeholder="Selçuk Yılmaz"
                className="w-full rounded-2xl border border-white/10 bg-slate-950/60 py-4 pl-4 pr-14 text-base font-medium text-white placeholder:text-slate-400 outline-none transition focus:border-blue-400 focus:bg-slate-950"
                onChange={(e) =>
                  setForm({
                    ...form,
                    name: e.target.value,
                  })
                }
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-white/70">
              Email Adresi
            </label>

            <div className="relative">
              <Mail
                size={20}
                className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400"
              />

              <input
                type="email"
                placeholder="ornek@email.com"
                className="w-full rounded-2xl border border-white/10 bg-slate-950/60 py-4 pl-4 pr-14 text-base font-medium text-white placeholder:text-slate-400 outline-none transition focus:border-blue-400 focus:bg-slate-950"
                onChange={(e) =>
                  setForm({
                    ...form,
                    email: e.target.value,
                  })
                }
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-black">Şifre</label>

            <div className="relative">
              <Lock
                size={20}
                className="absolute right-5 top-1/2 -translate-y-1/2 text-black"
              />

              <input
                type="password"
                placeholder="••••••••"
                className="w-full rounded-2xl border  py-4 pl-4 pr-14 text-base font-medium text-black placeholder:text-slate-400 outline-none transition focus:border-blue-400 focus:bg-slate-950"
                onChange={(e) =>
                  setForm({
                    ...form,
                    password: e.target.value,
                  })
                }
              />
            </div>
          </div>

          <button className="flex w-full items-center justify-center gap-2 rounded-2xl  px-6 py-4 text-lg font-black text-black shadow-xl transition hover:scale-[1.01] hover:opacity-95">
            <UserPlus size={22} />
            Kayıt Ol
          </button>
        </form>
      </div>
    </main>
  );
}
