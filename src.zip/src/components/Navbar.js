"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Menu, X, ShoppingCart, LogOut } from "lucide-react";
import { useCartStore } from "@/store/cartStore";
import { signOut, useSession } from "next-auth/react";
import { usePathname } from "next/navigation";
import axios from "axios";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [categories, setCategories] = useState([]);

  const pathname = usePathname();
  const cart = useCartStore((state) => state.cart);
  const { data: session } = useSession();

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await axios.get(
          `/api/categories/from-products?t=${Date.now()}`,
        );

        setCategories(res.data);
      } catch {
        console.log("Kategori getirilemedi");
      }
    };

    fetchCategories();
  }, [pathname]);

  const isActive = (href) => pathname === href;

  return (
    <header className="sticky top-4 z-50 w-full mx-auto">
      <div
        className="flex h-20 items-center justify-around rounded-3xl border
       border-white/10 bg-white/10 shadow-2xl backdrop-blur-2xl"
      >
        <Link
          href="/"
          className="text-3xl font-black tracking-tight text-black"
        >
          E-Ticaret
        </Link>

        <nav className="hidden items-center gap-10 font-semibold text-black lg:flex">
          <Link
            href="/"
            className={`pb-2 transition ${
              isActive("/")
                ? "border-b-2  text-black underline-offset-1"
                : "hover:scale-105 "
            }`}
          >
            Ana Sayfa
          </Link>

          <Link
            href="/products"
            className={`pb-2 transition ${
              isActive("/products")
                ? "border-b-2 border-white text-black underline-offset-1"
                : "hover:scale-105 "
            }`}
          >
            Detaylı Ürün Arama
          </Link>

          <div className="group relative pb-2">
            <button className="transition hover:text-white">Kategoriler</button>

            <div className="absolute left-0 top-full z-50 hidden min-w-52 rounded-2xl border border-white/10 bg-slate-950/95 p-3 shadow-2xl backdrop-blur-xl group-hover:block">
              {categories.length === 0 ? (
                <div className="px-4 py-2 text-white/50">Kategori yok</div>
              ) : (
                categories.map((cat) => (
                  <Link
                    key={cat}
                    href={`/category/${encodeURIComponent(cat)}`}
                    className="block rounded-xl px-4 py-2 text-white/70 transition hover:bg-white/10 hover:text-white"
                  >
                    {cat}
                  </Link>
                ))
              )}
            </div>
          </div>

          <Link href="/track-order" className="transition hover:text-black">
            Sipariş Takip
          </Link>

          {session?.user?.role !== "admin" && session && (
            <Link href="/my-orders" className="transition hover:text-black">
              Siparişlerim
            </Link>
          )}

          {session?.user?.role === "admin" && (
            <Link href="/admin" className="transition ">
              Admin
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-5">
          {session?.user && (
            <div className="hidden flex-col items-end md:flex">
              <span className="text-sm text-black">Hoş geldin</span>

              <span className="font-bold text-black">{session.user.name}</span>
            </div>
          )}

          <Link href="/cart" className="relative text-black">
            <ShoppingCart size={28} />

            {cartCount > 0 && (
              <span className="absolute -right-3 -top-3 rounded-full px-2 py-0.5 text-xs text-black">
                {cartCount}
              </span>
            )}
          </Link>

          {session ? (
            <button
              onClick={() =>
                signOut({
                  callbackUrl: "/",
                })
              }
              className="hidden items-center gap-2 rounded-xl border px-6 py-3 font-bold text-black shadow backdrop-blur-xl transition hover:bg-white/20 md:flex"
            >
              <LogOut size={16} />
              Çıkış
            </button>
          ) : (
            <div className="hidden items-center gap-3 md:flex">
              <Link
                href="/login"
                className="w-fit px-5 flex items-center justify-center rounded-xl border border-white/10 bg-white/10 
                font-bold text-black shadow backdrop-blur-xl transition hover:bg-white/20"
              >
                Giriş
              </Link>

              <Link
                href="/register"
                className="w-20 px-5 flex items-center justify-center rounded-xl   font-bold text-black
                 shadow-xl transition hover:scale-[1.02] hover:opacity-95"
              >
                Kayıt Ol
              </Link>
            </div>
          )}

          <button
            className="text-white lg:hidden"
            onClick={() => setOpen(!open)}
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {open && (
        <div className="mx-auto mt-3 flex w-full flex-col gap-4 rounded-3xl border border-white/10 bg-slate-950/95 px-6 py-5 font-semibold text-white/80 shadow-2xl backdrop-blur-2xl lg:hidden">
          <Link
            href="/"
            onClick={() => setOpen(false)}
            className="transition hover:text-white"
          >
            Ana Sayfa
          </Link>

          <Link
            href="/products"
            onClick={() => setOpen(false)}
            className="transition hover:text-white"
          >
            Detaylı Ürün Arama
          </Link>

          <Link
            href="/track-order"
            onClick={() => setOpen(false)}
            className="transition hover:text-white"
          >
            Sipariş Takip
          </Link>

          {session?.user?.role !== "admin" && session && (
            <Link
              href="/my-orders"
              onClick={() => setOpen(false)}
              className="transition hover:text-white"
            >
              Siparişlerim
            </Link>
          )}

          {session?.user?.role === "admin" && (
            <Link
              href="/admin"
              onClick={() => setOpen(false)}
              className="transition hover:text-white"
            >
              Admin
            </Link>
          )}

          <div className="border-t border-white/10 pt-4">
            <p className="mb-2 font-black text-white">Kategoriler</p>

            {categories.length === 0 ? (
              <p className="text-sm text-white/50">Kategori yok</p>
            ) : (
              categories.map((cat) => (
                <Link
                  key={cat}
                  href={`/category/${encodeURIComponent(cat)}`}
                  onClick={() => setOpen(false)}
                  className="block py-2 transition hover:text-white"
                >
                  {cat}
                </Link>
              ))
            )}
          </div>

          {session ? (
            <button
              onClick={() =>
                signOut({
                  callbackUrl: "/",
                })
              }
              className="rounded-xl border border-white/10 bg-white/10 px-6 py-3 text-white transition hover:bg-white/20"
            >
              Çıkış
            </button>
          ) : (
            <Link
              href="/login"
              className="rounded-xl border border-white/10 bg-white/10 px-6 py-3 text-center font-bold !text-white transition hover:bg-white/20"
            >
              Giriş
            </Link>
          )}
        </div>
      )}
    </header>
  );
}
