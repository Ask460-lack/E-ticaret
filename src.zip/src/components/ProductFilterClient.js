"use client";

import { useMemo, useState } from "react";
import ProductCard from "@/components/ProductCard";
import Navbar from "./Navbar";

export default function ProductFilterClient({ products }) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [inStockOnly, setInStockOnly] = useState(false);

  const categories = useMemo(() => {
    return [
      "all",
      ...new Set(
        products.map((product) => product.category?.trim()).filter(Boolean),
      ),
    ];
  }, [products]);

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const title = product.title?.toLowerCase() || "";
      const desc = product.description?.toLowerCase() || "";
      const searchValue = search.toLowerCase();

      const matchesSearch =
        title.includes(searchValue) || desc.includes(searchValue);

      const matchesCategory =
        category === "all" || product.category === category;

      const matchesMin = minPrice === "" || product.price >= Number(minPrice);

      const matchesMax = maxPrice === "" || product.price <= Number(maxPrice);

      const matchesStock = !inStockOnly || Number(product.stock) > 0;

      return (
        matchesSearch &&
        matchesCategory &&
        matchesMin &&
        matchesMax &&
        matchesStock
      );
    });
  }, [products, search, category, minPrice, maxPrice, inStockOnly]);

  const resetFilters = () => {
    setSearch("");
    setCategory("all");
    setMinPrice("");
    setMaxPrice("");
    setInStockOnly(false);
  };

  return (
    <main className="mx-auto w-full max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <Navbar />
      <div className="h-50 flex flex-col items-center text-center space-y-5 gap-5">
        <div className="mb-5 inline-flex rounded-full border border-white/10 bg-white/10 px-4 py-2 backdrop-blur-xl">
          <span className="text-sm font-semibold text-white/70">
            Premium Search
          </span>
        </div>

        <h1
          className="bg-gradient-to-r from-white via-blue-200 to-purple-300 
        bg-clip-text text-4xl  font-black text-transparent md:text-6xl"
        >
          Ürünler
        </h1>

        <p className="mt-5 max-w-2xl text-base leading-8 text-white/70 md:text-lg">
          Ürünleri arayın, kategorilere göre filtreleyin ve size en uygun
          ürünleri kolayca keşfedin.
        </p>
      </div>

      <div className="grid h-fit gap-5 md:grid-cols-5 mb-5">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Ürün ara..."
          className="rounded-2xl border border-white/10 bg-slate-950/40 p-4 text-black placeholder:text-slate-500 placeholder:pl-1.5 outline-none transition focus:border-blue-400 md:col-span-2"
        />

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="rounded-2xl border  p-4 text-black outline-none transition focus:border-blue-400"
        >
          {categories.map((cat) => (
            <option
              key={cat}
              value={cat}
              className=" bg-slate-950/40 text-black "
            >
              {cat === "all" ? "Tüm Kategoriler" : cat}
            </option>
          ))}
        </select>

        <input
          type="number"
          value={minPrice}
          onChange={(e) => setMinPrice(e.target.value)}
          placeholder="Min fiyat"
          className="rounded-2xl border p-4 text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400"
        />

        <input
          type="number"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
          placeholder="Max fiyat"
          className="rounded-2xl border  p-4 text-black placeholder:text-slate-500 outline-none transition focus:border-blue-400 placeholder:pl-1.5"
        />

        <label className="flex items-center gap-3 rounded-2xl border px-5 py-4 text-black/80 md:col-span-2">
          <input
            type="checkbox"
            checked={inStockOnly}
            onChange={(e) => setInStockOnly(e.target.checked)}
            className="h-5 w-5 accent-blue-500"
          />
          <span className="font-medium">Sadece stokta olan ürünler</span>
        </label>

        <button
          onClick={resetFilters}
          className="rounded-2xl border  px-5 py-4 font-bold text-black transition hover:bg-white/20"
        >
          Filtreleri Temizle
        </button>

        <div className="flex items-center justify-end text-sm font-semibold text-black md:col-span-2">
          {filteredProducts.length} ürün bulundu
        </div>
      </div>
      <div className="w-screen h-8"></div>
      {filteredProducts.length === 0 ? (
        <div className="rounded-[32px] border  p-12 text-center shadow-2xl backdrop-blur-2xl">
          <h2 className="text-3xl font-black text-black">Ürün bulunamadı</h2>

          <p className="mt-4 text-lg leading-8 text-black/65">
            Arama veya filtre seçeneklerini değiştirerek tekrar deneyin.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
          {filteredProducts.map((product) => (
            <ProductCard key={product._id} product={product} />
          ))}
        </div>
      )}
    </main>
  );
}
