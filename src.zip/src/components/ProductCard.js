"use client";

import Image from "next/image";
import Link from "next/link";
import { ShoppingCart, Eye } from "lucide-react";
import { useCartStore } from "@/store/cartStore";
import { useSession } from "next-auth/react";
import Navbar from "./Navbar";

export default function ProductCard({ product }) {
  const addToCart = useCartStore((state) => state.addToCart);
  const { data: session } = useSession();

  return (
    <div className="group flex h-full w-full flex-col overflow-hidden rounded-[32px] border  text-black shadow-2xl backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:border-white/20 hover:bg-white/15">
      <Navbar />
      <Link href={`/products/${product._id}`} className="block">
        <div className="relative flex h-[320px] w-full items-center justify-center overflow-hidden p-6">
          <Image
            src={product.images?.[0]}
            width={600}
            height={450}
            alt={product.title}
            className="h-full w-full object-contain transition duration-500 group-hover:scale-105"
          />

          <div className="absolute right-4 top-4 rounded-full px-3 py-1 text-xs font-bold text-black shadow-lg">
            Yeni
          </div>
        </div>
      </Link>

      <div className="flex flex-1 flex-col p-6">
        <Link href={`/products/${product._id}`}>
          <h2 className="min-h-[56px] text-center text-xl font-black leading-tight text-black transition hover:text-blue-200 line-clamp-2">
            {product.title}
          </h2>
        </Link>

        <p className="my-5 text-center text-3xl font-black text-black">
          ₺{Number(product.price).toLocaleString("tr-TR")}
        </p>

        <div className="mt-6 flex flex-col gap-3">
          <Link
            href={`/products/${product._id}`}
            className="flex w-full items-center justify-center gap-2 
            rounded-2xl border border-white/10 bg-white/10 px-4 
            py-3 font-bold text-black transition hover:bg-white/20
            my-5"
          >
            <Eye size={18} />
            Detayları Gör
          </Link>

          {session?.user?.role !== "admin" && (
            <button
              onClick={() => addToCart(product)}
              className="flex w-full items-center justify-center 
              gap-2 rounded-2xl  px-4 py-4 font-bold text-black shadow-lg 
               transition hover:scale-[1.02] hover:opacity-95 mb-10"
            >
              <ShoppingCart size={18} />
              Sepete Ekle
            </button>
          )}
          <div className="h-1"></div>
        </div>
      </div>
    </div>
  );
}
