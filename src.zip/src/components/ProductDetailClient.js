"use client";

import { useState } from "react";
import Image from "next/image";
import { ShoppingCart, PackageCheck } from "lucide-react";
import { useCartStore } from "@/store/cartStore";
import { useSession } from "next-auth/react";
import Navbar from "./Navbar";

export default function ProductDetailClient({ product }) {
  const [activeImage, setActiveImage] = useState(product.images?.[0]);

  const addToCart = useCartStore((state) => state.addToCart);
  const { data: session } = useSession();

  return (
    <main className=" container mx-auto flex justify-center gap-12 px-4 py-10 sm:px-6  lg:gap-16 lg:px-8">
      <Navbar />
      <div className=" flex flex-col lg:flex-row gap-5 ">
        <div className="w-full ">
          <div className="rounded-[36px] border border-white/10 bg-white/10 p-4 shadow-2xl backdrop-blur-2xl">
            <Image
              src={activeImage}
              width={700}
              height={700}
              alt={product.title}
              className="h-[360px] w-full rounded-[28px] bg-white object-contain p-6 shadow-xl sm:h-[430px] lg:h-[500px]"
            />
          </div>

          <div className="mt-5 flex gap-3 overflow-x-auto pb-2">
            {product.images?.map((img, index) => (
              <button
                key={index}
                onClick={() => setActiveImage(img)}
                className={`shrink-0 overflow-hidden rounded-2xl border p-1 transition ${
                  activeImage === img
                    ? "border-blue-400 bg-blue-400/20"
                    : "border-white/10 bg-white/10 hover:border-white/30"
                }`}
              >
                <Image
                  src={img}
                  width={100}
                  height={100}
                  alt="Ürün görseli"
                  className="h-24 w-24 rounded-xl bg-white object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        <div className="w-full h-fit  rounded-[36px] border  p-6 text-black shadow-2xl backdrop-blur-2xl sm:p-8 lg:p-10">
          <p className="inline-flex rounded-full border border-blue-300/20 bg-blue-400/10 px-4 py-2 text-sm font-bold uppercase tracking-widest text-blue-100">
            {product.category}
          </p>

          <h1 className="mt-6 text-3xl font-black leading-tight text-white sm:text-4xl lg:text-5xl">
            {product.title}
          </h1>

          <p className="mt-8 text-4xl font-black text-blue-200">
            ₺{Number(product.price).toLocaleString("tr-TR")}
          </p>

          <div className="mt-8 rounded-3xl border border-white/10 bg-slate-950/40 p-5">
            <h2 className="mb-3 text-lg font-black text-white">
              Ürün Açıklaması
            </h2>

            <p className="leading-8 text-white/75">
              {product.description || "Bu ürün için henüz açıklama eklenmedi."}
            </p>
          </div>

          <div className="mt-6 flex items-center gap-3 rounded-2xl border border-white/10 bg-white/10 px-5 py-4 text-white/80">
            <PackageCheck size={22} className="text-blue-200" />
            <span className="font-semibold">
              Stok Durumu:{" "}
              <strong className="text-white">{product.stock}</strong>
            </span>
          </div>

          {session?.user?.role !== "admin" && (
            <button
              onClick={() => addToCart(product)}
              className="mt-8 flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500 px-8 py-4 text-lg font-black text-white shadow-xl transition hover:scale-[1.02] hover:opacity-95"
            >
              <ShoppingCart size={22} />
              Sepete Ekle
            </button>
          )}
        </div>
      </div>
    </main>
  );
}
